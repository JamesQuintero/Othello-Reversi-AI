# Othello-AI
AI that can play Othello, for CS 271 Artificial Intelligence class at UCI
