
To build the program: 
> g++ -std=c++11 *.cpp -o Othello.out

To play: 
> Othello.out