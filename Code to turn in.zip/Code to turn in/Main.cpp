

#include <iostream>
#include "Othello.h"

using namespace std;


int main(int argc, char** argv)
{
	Othello othello;
	othello.run();

	
	system("pause");
	return 0;
}
